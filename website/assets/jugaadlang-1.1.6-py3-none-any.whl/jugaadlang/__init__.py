"""JugaadLang — The Hindi-keyword programming language. 🇮🇳"""

__version__ = "1.1.6"
__author__ = "JugaadLang Community"
__license__ = "MIT"
__url__ = "https://jugaadlang.netlify.app"
