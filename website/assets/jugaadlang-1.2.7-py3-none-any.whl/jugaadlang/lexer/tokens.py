"""
JugaadLang Token Types and Keyword Mapping.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class TokenType(Enum):
    # ── Literals ──────────────────────────────────────────────────────
    INT = auto()
    FLOAT = auto()
    STRING = auto()
    FSTRING = auto()
    TSTRING = auto()

    # ── Identifier ───────────────────────────────────────────────────
    IDENTIFIER = auto()

    # ── JugaadLang Keywords ──────────────────────────────────────────
    BOLO = auto()              # print
    POOCHHO = auto()           # input
    AGAR = auto()              # if
    SHAYAD = auto()            # elif
    WARNA = auto()             # else
    GHUMO = auto()             # for
    JABTAK = auto()            # while
    BANAO = auto()             # def
    WAPAS = auto()             # return
    USTAD = auto()             # class
    KHUD = auto()              # self
    LAO = auto()               # import
    SE = auto()                # from
    RUKJA = auto()             # break
    CHALTE_RAHO = auto()      # continue
    KOSHISH = auto()           # try
    GADBAD = auto()            # except
    AAKHIR_ME = auto()         # finally
    UDAO = auto()              # raise
    SAHI = auto()              # True
    GALAT = auto()             # False
    KUCH_NAHI = auto()        # None
    AUR = auto()               # and
    YA = auto()                # or
    NAHI = auto()              # not
    TEZ = auto()               # async
    INTEZAAR = auto()          # await
    BAANTO = auto()            # yield
    THEEK_HAI = auto()        # pass
    SABKA = auto()             # global
    CHOTA_FUNKSHAN = auto()   # lambda
    MEIN = auto()              # in
    MEIN_NAHI = auto()        # not in
    HAI = auto()               # is
    NAHI_HAI = auto()         # is not
    BULAWO = auto()            # call
    DEL = auto()               # del
    NONLOCAL = auto()          # nonlocal
    WITH = auto()              # with
    AS = auto()                # as
    ASSERT = auto()            # assert
    AGAR_MATCH = auto()       # match
    KAAND = auto()             # case

    # ── Operators ────────────────────────────────────────────────────
    PLUS = auto()              # +
    MINUS = auto()             # -
    STAR = auto()              # *
    SLASH = auto()             # /
    DOUBLESLASH = auto()      # //
    PERCENT = auto()           # %
    DOUBLESTAR = auto()       # **
    EQ = auto()                # ==
    NEQ = auto()               # !=
    LT = auto()                # <
    GT = auto()                # >
    LTE = auto()               # <=
    GTE = auto()               # >=
    ASSIGN = auto()            # =
    PLUS_ASSIGN = auto()       # +=
    MINUS_ASSIGN = auto()      # -=
    STAR_ASSIGN = auto()       # *=
    SLASH_ASSIGN = auto()      # /=
    PERCENT_ASSIGN = auto()    # %=
    DOUBLESTAR_ASSIGN = auto() # **=
    DOUBLESLASH_ASSIGN = auto() # //=
    ARROW = auto()             # ->
    WALRUS = auto()            # :=
    AT = auto()                # @
    AT_ASSIGN = auto()         # @=
    TILDE = auto()             # ~
    AMP = auto()               # &
    PIPE = auto()              # |
    CARET = auto()             # ^
    LSHIFT = auto()            # <<
    RSHIFT = auto()            # >>
    AMP_ASSIGN = auto()        # &=
    PIPE_ASSIGN = auto()       # |=
    CARET_ASSIGN = auto()      # ^=
    LSHIFT_ASSIGN = auto()    # <<=
    RSHIFT_ASSIGN = auto()    # >>=

    # ── Delimiters ───────────────────────────────────────────────────
    LPAREN = auto()            # (
    RPAREN = auto()            # )
    LBRACKET = auto()          # [
    RBRACKET = auto()          # ]
    LBRACE = auto()            # {
    RBRACE = auto()            # }
    COMMA = auto()              # ,
    DOT = auto()                # .
    COLON = auto()              # :
    SEMICOLON = auto()         # ;
    ELLIPSIS = auto()           # ...

    # ── Layout ───────────────────────────────────────────────────────
    NEWLINE = auto()
    INDENT = auto()
    DEDENT = auto()

    # ── Special ──────────────────────────────────────────────────────
    COMMENT = auto()
    EOF = auto()


# ── Keyword string → TokenType mapping ───────────────────────────────

KEYWORDS: dict[str, TokenType] = {
    "bolo": TokenType.BOLO,
    "poochho": TokenType.POOCHHO,
    "agar": TokenType.AGAR,
    "shayad": TokenType.SHAYAD,
    "warna": TokenType.WARNA,
    "ghumo": TokenType.GHUMO,
    "jabtak": TokenType.JABTAK,
    "banao": TokenType.BANAO,
    "wapas": TokenType.WAPAS,
    "ustad": TokenType.USTAD,
    "khud": TokenType.KHUD,
    "lao": TokenType.LAO,
    "se": TokenType.SE,
    "rukja": TokenType.RUKJA,
    "chalte_raho": TokenType.CHALTE_RAHO,
    "koshish": TokenType.KOSHISH,
    "gadbad": TokenType.GADBAD,
    "aakhir_me": TokenType.AAKHIR_ME,
    "udao": TokenType.UDAO,
    "sahi": TokenType.SAHI,
    "galat": TokenType.GALAT,
    "kuch_nahi": TokenType.KUCH_NAHI,
    "aur": TokenType.AUR,
    "ya": TokenType.YA,
    "nahi": TokenType.NAHI,
    "tez": TokenType.TEZ,
    "intezaar": TokenType.INTEZAAR,
    "baanto": TokenType.BAANTO,
    "theek_hai": TokenType.THEEK_HAI,
    "sabka": TokenType.SABKA,
    "chota_funkshan": TokenType.CHOTA_FUNKSHAN,
    "mein": TokenType.MEIN,
    "mein_nahi": TokenType.MEIN_NAHI,
    "hai": TokenType.HAI,
    "nahi_hai": TokenType.NAHI_HAI,
    "bulawo": TokenType.BULAWO,
    "del": TokenType.DEL,
    "hatao": TokenType.DEL,
    "nonlocal": TokenType.NONLOCAL,
    "gair_local": TokenType.NONLOCAL,
    "with": TokenType.WITH,
    "ke_saath": TokenType.WITH,
    "as": TokenType.AS,
    "jaise": TokenType.AS,
    "assert": TokenType.ASSERT,
    "pakka": TokenType.ASSERT,
    "agar_match": TokenType.AGAR_MATCH,
    "kaand": TokenType.KAAND,
}


# ── Human-readable names for error messages ──────────────────────────

TOKEN_NAMES: dict[TokenType, str] = {
    TokenType.INT: "integer",
    TokenType.FLOAT: "float",
    TokenType.STRING: "string",
    TokenType.FSTRING: "f-string",
    TokenType.TSTRING: "t-string",
    TokenType.IDENTIFIER: "identifier",

    TokenType.NEWLINE: "newline",
    TokenType.INDENT: "indent",
    TokenType.DEDENT: "dedent",
    TokenType.EOF: "end of file",

    TokenType.LPAREN: "'('",
    TokenType.RPAREN: "')'",
    TokenType.LBRACKET: "'['",
    TokenType.RBRACKET: "']'",
    TokenType.LBRACE: "'{'",
    TokenType.RBRACE: "'}'",

    TokenType.COMMA: "','",
    TokenType.DOT: "'.'",
    TokenType.COLON: "':'",
    TokenType.SEMICOLON: "';'",
    TokenType.ELLIPSIS: "'...'",

    TokenType.ASSIGN: "'='",
    TokenType.EQ: "'=='",
    TokenType.NEQ: "'!='",
    TokenType.LT: "'<'",
    TokenType.GT: "'>'",
    TokenType.LTE: "'<='",
    TokenType.GTE: "'>='",
    TokenType.ARROW: "'->'",
}


@dataclass(slots=True)
class Token:
    """A single lexical token."""

    type: TokenType
    value: str
    line: int
    col: int

    def __repr__(self) -> str:
        return (
            f"Token({self.type.name}, "
            f"{self.value!r}, "
            f"{self.line}:{self.col})"
        )

    def is_keyword(self) -> bool:
        return self.type in KEYWORDS.values()
